#ifndef LCD_I2C_H
#define LCD_I2C_H

#include "main.h"

#define LCD_COLUMNS 16u
#define LCD_ROWS    2u

void LCD_Init(void);
void LCD_Clear(void);
void LCD_SetCursor(uint8_t column, uint8_t row);
void LCD_WriteChar(uint8_t value);
void LCD_CreateChar(uint8_t location, const uint8_t glyph[8]);

#endif
