#ifndef VU_TYPES_H
#define VU_TYPES_H

#include <stdint.h>

typedef enum {
    VU_DIR_LEFT_TO_RIGHT,
    VU_DIR_RIGHT_TO_LEFT,
    VU_DIR_CENTER_OUT
} VuDirection;

typedef enum {
    VU_DISPLAY_CARACTER,
    VU_DISPLAY_STEP
} VuDisplayMode;

#endif
