#include "main.h"
#include "caracter.h"
#include "lcd_i2c.h"
#include "lepcso.h"
#include "vu_types.h"

/* External 8 MHz crystal configuration. */
#pragma config FOSC = HS, PLLEN = OFF, PCLKEN = ON, FCMEN = OFF, IESO = OFF
#pragma config PWRTEN = ON, BOREN = OFF, BORV = 19
#pragma config WDTEN = OFF
#pragma config MCLRE = ON, STVREN = ON, LVP = OFF, XINST = OFF

#define TIMER0_RELOAD_HIGH       0xFFu
#define TIMER0_RELOAD_LOW        0x06u  /* 1 ms at Fosc=8 MHz, prescaler 1:8 */

#define BUTTON_UP                0x01u
#define BUTTON_DOWN              0x02u
#define BUTTON_MODE              0x04u
#define BUTTON_MENU              0x08u
#define BUTTON_POLL_MS           10UL
#define BUTTON_DEBOUNCE_COUNT    3u

#define VU_BAR_COLUMNS           15u
#define VU_STEP_MAX              (VU_BAR_COLUMNS * 5u)
#define VU_ADC_REFERENCE_TENTHS  50u    /* 5.0 V ADC reference (VDD) */
#define CHARACTER_SPEED_MAX      10u
#define STEP_SPEED_MAX           15u

#define EEPROM_MAGIC             0xB6u
#define EE_MAGIC                 0x00u
#define EE_INPUT_TENTHS          0x01u
#define EE_CHAR_RISE             0x02u
#define EE_CHAR_FALL             0x03u
#define EE_DISPLAY_MODE          0x04u
#define EE_STEP_RISE             0x05u
#define EE_STEP_FALL             0x06u
#define EE_CHAR_PATTERN          0x07u
#define EE_STEP_PATTERN          0x08u
#define EE_DIRECTION             0x09u
#define EE_CHECK                 0x0Au

typedef enum {
    APP_METER,
    APP_MENU
} AppState;

typedef enum {
    MENU_INPUT,
    MENU_CHARACTER_SPEED,
    MENU_DISPLAY_TYPE,
    MENU_STEP_SPEED
} MenuPage;

typedef struct {
    uint8_t inputTenths;
    uint8_t characterRise;
    uint8_t characterFall;
    uint8_t displayMode;
    uint8_t stepRise;
    uint8_t stepFall;
    uint8_t characterPattern;
    uint8_t stepPattern;
    uint8_t direction;
} VuSettings;

static volatile uint32_t milliseconds = 0UL;
static AppState appState = APP_METER;
static MenuPage menuPage = MENU_INPUT;
static VuSettings settings = {10u, 3u, 3u, VU_DISPLAY_CARACTER,
                              3u, 3u, 0u, 0u, VU_DIR_LEFT_TO_RIGHT};

static uint8_t targetLeft = 0u;
static uint8_t targetRight = 0u;
static uint8_t displayedLeft = 0u;
static uint8_t displayedRight = 0u;
static uint32_t lastSampleAt = 0UL;
static uint32_t lastLeftStepAt = 0UL;
static uint32_t lastRightStepAt = 0UL;

static uint8_t buttonStable = 0u;
static uint8_t buttonLastRaw = 0u;
static uint8_t buttonDebounce[4] = {0u, 0u, 0u, 0u};
static uint32_t lastButtonPollAt = 0UL;
static const uint8_t buttonMasks[4] = {
    BUTTON_UP, BUTTON_DOWN, BUTTON_MODE, BUTTON_MENU
};

static uint8_t lcdCache[2][LCD_COLUMNS];
static bool lcdRowValid[2] = {false, false};
static uint8_t loadedCharacterPattern = 0xFFu;
static uint8_t loadedStepPattern = 0xFFu;
static bool loadedStepMirror = false;

static void Hardware_Init(void);
static void Timer0_Init(void);
static void ADC_Init(void);
static uint16_t ADC_Read(uint8_t channel);
static uint32_t Millis(void);
static uint8_t Buttons_ReadRaw(void);
static void Buttons_Init(uint32_t now);
static uint8_t Buttons_Update(uint32_t now);
static uint8_t ScaleInput(uint16_t adcValue, uint8_t maximum);
static uint16_t SpeedInterval(bool rising);
static uint8_t SpeedIncrement(bool rising);
static bool UpdateChannel(uint8_t *displayed, uint8_t target,
                          uint32_t *lastStepAt, uint32_t now);
static void UpdateInputs(uint32_t now);
static void UpdateMeter(uint32_t now);
static void CharacterGlyphs_Ensure(void);
static void StepGlyphs_Ensure(void);
static void LCD_Invalidate(void);
static void LCD_WriteLineChanged(uint8_t row, const uint8_t line[LCD_COLUMNS]);
static void LCD_WriteText(const char *text);
static void RenderMeter(void);
static void Line_Blank(uint8_t line[LCD_COLUMNS]);
static void Line_Text(uint8_t line[LCD_COLUMNS], uint8_t position, const char *text);
static void Line_SpeedValue(uint8_t line[LCD_COLUMNS], uint8_t position, uint8_t value);
static void LCD_ShowMenu(void);
static void Settings_Defaults(void);
static void Settings_Validate(void);
static uint8_t EEPROM_Read(uint8_t address);
static void EEPROM_Write(uint8_t address, uint8_t value);
static uint8_t Settings_Checksum(void);
static void Settings_Load(void);
static void Settings_Save(void);
static void Value_Next(uint8_t *value, uint8_t maximum);
static void Value_Previous(uint8_t *value, uint8_t maximum);
static void HandleMeterButtons(uint8_t events);
static void HandleMenuButtons(uint8_t events);

void __interrupt() InterruptServiceRoutine(void)
{
    if (INTCONbits.TMR0IF != 0u) {
        TMR0H = TIMER0_RELOAD_HIGH;
        TMR0L = TIMER0_RELOAD_LOW;
        INTCONbits.TMR0IF = 0;
        milliseconds++;
    }
}

void main(void)
{
    uint32_t now;
    uint8_t buttonEvents;
    uint8_t splashIndex;

    Hardware_Init();
    ADC_Init();
    LCD_Init();

    /* LCD test copied from the known working standalone program. */
    LCD_Clear();
    LCD_SetCursor(0u, 0u);
    LCD_WriteText("  PIC18F14K22  ");
    LCD_SetCursor(0u, 1u);
    LCD_WriteText("I2C LCD VUMETER");
    for (splashIndex = 0u; splashIndex < 50u; splashIndex++) {
        __delay_ms(100);
    }

    /* Start the 1 ms interrupt only after the software-I2C LCD test. */
    Timer0_Init();
    Settings_Load();

    now = Millis();
    Buttons_Init(now);
    LCD_Invalidate();
    RenderMeter();

    for (;;) {
        now = Millis();
        buttonEvents = Buttons_Update(now);

        if (appState == APP_METER) {
            UpdateMeter(now);
            if (buttonEvents != 0u) {
                HandleMeterButtons(buttonEvents);
            }
        } else if (buttonEvents != 0u) {
            HandleMenuButtons(buttonEvents);
        }
    }
}

static void Hardware_Init(void)
{
    ANSEL = 0x30u;                      /* RC0/AN4 = L, RC1/AN5 = R */
    ANSELH = 0x00u;
    CM1CON0 = 0x00u;
    CM2CON0 = 0x00u;

    LATA = 0x00u;
    LATB = 0x00u;
    LATC = 0x00u;
    TRISA = 0xFFu;
    TRISB = 0xFFu;
    TRISC = 0xFFu;

    TRISAbits.TRISA2 = 1;               /* MENU */
    TRISCbits.TRISC0 = 1;               /* L / AN4 */
    TRISCbits.TRISC1 = 1;               /* R / AN5 */
    TRISCbits.TRISC2 = 1;               /* MODE */
    TRISCbits.TRISC4 = 1;               /* UP */
    TRISCbits.TRISC5 = 1;               /* DOWN */

}

static void Timer0_Init(void)
{
    RCONbits.IPEN = 0;
    T0CON = 0x02u;                      /* 16 bit, Fosc/4, 1:8, timer stopped */
    TMR0H = TIMER0_RELOAD_HIGH;
    TMR0L = TIMER0_RELOAD_LOW;
    INTCONbits.TMR0IF = 0;
    INTCONbits.TMR0IE = 1;
    INTCONbits.GIE = 1;
    T0CONbits.TMR0ON = 1;
}

static void ADC_Init(void)
{
    ADCON1 = 0x00u;                     /* VDD/VSS references */
    ADCON2 = 0xA6u;                     /* right aligned, 8 TAD, Fosc/64 */
    ADCON0 = 0x01u;                     /* ADC on */
}

static uint16_t ADC_Read(uint8_t channel)
{
    ADCON0bits.CHS = channel;
    __delay_us(20);
    ADCON0bits.GO_nDONE = 1;
    while (ADCON0bits.GO_nDONE != 0u) {
    }
    return (uint16_t)(((uint16_t)ADRESH << 8) | ADRESL);
}

static uint32_t Millis(void)
{
    uint8_t interruptsEnabled;
    uint32_t result;

    interruptsEnabled = INTCONbits.GIE;
    INTCONbits.GIE = 0;
    result = milliseconds;
    INTCONbits.GIE = interruptsEnabled;
    return result;
}

static uint8_t Buttons_ReadRaw(void)
{
    uint8_t result = 0u;

    /* All buttons are active-low and need external pull-up resistors. */
    if (PORTCbits.RC4 == 0u) {
        result |= BUTTON_UP;
    }
    if (PORTCbits.RC5 == 0u) {
        result |= BUTTON_DOWN;
    }
    if (PORTCbits.RC2 == 0u) {
        result |= BUTTON_MODE;
    }
    if (PORTAbits.RA2 == 0u) {
        result |= BUTTON_MENU;
    }
    return result;
}

static void Buttons_Init(uint32_t now)
{
    buttonStable = Buttons_ReadRaw();
    buttonLastRaw = buttonStable;
    buttonDebounce[0] = 0u;
    buttonDebounce[1] = 0u;
    buttonDebounce[2] = 0u;
    buttonDebounce[3] = 0u;
    lastButtonPollAt = now;
}

static uint8_t Buttons_Update(uint32_t now)
{
    uint8_t events = 0u;
    uint8_t raw;
    uint8_t index;

    if ((uint32_t)(now - lastButtonPollAt) < BUTTON_POLL_MS) {
        return 0u;
    }
    lastButtonPollAt = now;
    raw = Buttons_ReadRaw();

    for (index = 0u; index < 4u; index++) {
        uint8_t mask = buttonMasks[index];
        bool rawPressed = ((raw & mask) != 0u);
        bool previousRawPressed = ((buttonLastRaw & mask) != 0u);
        bool stablePressed = ((buttonStable & mask) != 0u);

        if (rawPressed != previousRawPressed) {
            if (rawPressed) {
                buttonLastRaw |= mask;
            } else {
                buttonLastRaw &= (uint8_t)~mask;
            }
            buttonDebounce[index] = 0u;
        } else if (buttonDebounce[index] < BUTTON_DEBOUNCE_COUNT) {
            buttonDebounce[index]++;
            if ((buttonDebounce[index] >= BUTTON_DEBOUNCE_COUNT) &&
                (rawPressed != stablePressed)) {
                if (rawPressed) {
                    buttonStable |= mask;
                    events |= mask;
                } else {
                    buttonStable &= (uint8_t)~mask;
                }
            }
        }
    }
    return events;
}

static uint8_t ScaleInput(uint16_t adcValue, uint8_t maximum)
{
    uint16_t fullScale;
    uint32_t result;

    fullScale = (uint16_t)(((uint16_t)settings.inputTenths * 1023u) /
                           VU_ADC_REFERENCE_TENTHS);
    if (fullScale == 0u) {
        fullScale = 1u;
    }
    result = ((uint32_t)adcValue * maximum) / fullScale;
    if (result > maximum) {
        result = maximum;
    }
    return (uint8_t)result;
}

static uint16_t SpeedInterval(bool rising)
{
    /* Levels 1..5 keep their original feel; 6..10 are progressively faster. */
    static const uint16_t characterInterval[CHARACTER_SPEED_MAX] = {
        170u, 130u, 90u, 55u, 25u, 20u, 16u, 12u, 8u, 4u
    };
    static const uint16_t stepInterval[STEP_SPEED_MAX] = {
        34u, 26u, 18u, 11u, 5u, 4u, 3u, 2u, 1u, 1u,
        1u, 1u, 1u, 1u, 1u
    };
    uint8_t speed;

    if (settings.displayMode == VU_DISPLAY_CARACTER) {
        speed = rising ? settings.characterRise : settings.characterFall;
        return characterInterval[speed - 1u];
    }

    speed = rising ? settings.stepRise : settings.stepFall;
    return stepInterval[speed - 1u];
}

static uint8_t SpeedIncrement(bool rising)
{
    uint8_t speed;

    if (settings.displayMode == VU_DISPLAY_CARACTER) {
        return 1u;
    }

    speed = rising ? settings.stepRise : settings.stepFall;
    if (speed <= 10u) {
        return 1u;
    }
    /* The step display has 5 sub-levels per LCD character.  Above 10,
       skip sub-levels so level 15 approaches the character-mode speed. */
    return (uint8_t)(speed - 9u);        /* 11->2 ... 15->6 */
}

static bool UpdateChannel(uint8_t *displayed, uint8_t target,
                          uint32_t *lastStepAt, uint32_t now)
{
    bool rising;
    uint8_t increment;

    if (*displayed == target) {
        return false;
    }
    rising = (*displayed < target);
    if ((uint32_t)(now - *lastStepAt) < SpeedInterval(rising)) {
        return false;
    }

    *lastStepAt = now;
    increment = SpeedIncrement(rising);
    if (rising) {
        if ((uint8_t)(target - *displayed) <= increment) {
            *displayed = target;
        } else {
            *displayed = (uint8_t)(*displayed + increment);
        }
    } else {
        if ((uint8_t)(*displayed - target) <= increment) {
            *displayed = target;
        } else {
            *displayed = (uint8_t)(*displayed - increment);
        }
    }
    return true;
}

static void UpdateInputs(uint32_t now)
{
    uint8_t maximum;

    if ((uint32_t)(now - lastSampleAt) < 10UL) {
        return;
    }
    lastSampleAt = now;
    maximum = (settings.displayMode == VU_DISPLAY_CARACTER) ?
              VU_BAR_COLUMNS : VU_STEP_MAX;
    targetLeft = ScaleInput(ADC_Read(4u), maximum);      /* RC0 / AN4 */
    targetRight = ScaleInput(ADC_Read(5u), maximum);     /* RC1 / AN5 */
}

static void UpdateMeter(uint32_t now)
{
    bool redraw = false;

    UpdateInputs(now);
    if (UpdateChannel(&displayedLeft, targetLeft, &lastLeftStepAt, now)) {
        redraw = true;
    }
    if (UpdateChannel(&displayedRight, targetRight, &lastRightStepAt, now)) {
        redraw = true;
    }
    if (redraw) {
        RenderMeter();
    }
}

static void CharacterGlyphs_Ensure(void)
{
    if (settings.displayMode != VU_DISPLAY_CARACTER) {
        return;
    }
    if (loadedCharacterPattern != settings.characterPattern) {
        Caracter_LoadPattern(settings.characterPattern);
        loadedCharacterPattern = settings.characterPattern;
        LCD_Invalidate();
    }
}

static void StepGlyphs_Ensure(void)
{
    bool mirrored;

    if (settings.displayMode != VU_DISPLAY_STEP) {
        return;
    }
    mirrored = (settings.direction == VU_DIR_RIGHT_TO_LEFT);
    if ((loadedStepPattern != settings.stepPattern) ||
        (loadedStepMirror != mirrored)) {
        Lepcso_LoadPattern(settings.stepPattern, mirrored);
        loadedStepPattern = settings.stepPattern;
        loadedStepMirror = mirrored;
        LCD_Invalidate();
    }
}

static void LCD_Invalidate(void)
{
    lcdRowValid[0] = false;
    lcdRowValid[1] = false;
}

static void LCD_WriteLineChanged(uint8_t row, const uint8_t line[LCD_COLUMNS])
{
    uint8_t column = 0u;

    while (column < LCD_COLUMNS) {
        if ((!lcdRowValid[row]) || (lcdCache[row][column] != line[column])) {
            LCD_SetCursor(column, row);
            do {
                LCD_WriteChar(line[column]);
                lcdCache[row][column] = line[column];
                column++;
            } while ((column < LCD_COLUMNS) &&
                     ((!lcdRowValid[row]) || (lcdCache[row][column] != line[column])));
        } else {
            column++;
        }
    }
    lcdRowValid[row] = true;
}

static void LCD_WriteText(const char *text)
{
    while (*text != '\0') {
        LCD_WriteChar((uint8_t)*text);
        text++;
    }
}

static void RenderMeter(void)
{
    uint8_t leftLine[LCD_COLUMNS];
    uint8_t rightLine[LCD_COLUMNS];
    uint8_t bar[VU_BAR_COLUMNS];
    uint8_t index;
    VuDirection direction = (VuDirection)settings.direction;

    if (settings.displayMode == VU_DISPLAY_CARACTER) {
        CharacterGlyphs_Ensure();
        Caracter_Render(bar, VU_BAR_COLUMNS, displayedLeft,
                         settings.characterPattern, direction);
    } else {
        StepGlyphs_Ensure();
        Lepcso_Render(bar, VU_BAR_COLUMNS, displayedLeft, direction);
    }
    leftLine[0] = 'L';
    for (index = 0u; index < VU_BAR_COLUMNS; index++) {
        leftLine[(uint8_t)(index + 1u)] = bar[index];
    }

    if (settings.displayMode == VU_DISPLAY_CARACTER) {
        Caracter_Render(bar, VU_BAR_COLUMNS, displayedRight,
                         settings.characterPattern, direction);
    } else {
        Lepcso_Render(bar, VU_BAR_COLUMNS, displayedRight, direction);
    }
    rightLine[0] = 'R';
    for (index = 0u; index < VU_BAR_COLUMNS; index++) {
        rightLine[(uint8_t)(index + 1u)] = bar[index];
    }

    LCD_WriteLineChanged(0u, leftLine);
    LCD_WriteLineChanged(1u, rightLine);
}

static void Line_Blank(uint8_t line[LCD_COLUMNS])
{
    uint8_t index;
    for (index = 0u; index < LCD_COLUMNS; index++) {
        line[index] = ' ';
    }
}

static void Line_Text(uint8_t line[LCD_COLUMNS], uint8_t position, const char *text)
{
    while ((*text != '\0') && (position < LCD_COLUMNS)) {
        line[position++] = (uint8_t)*text;
        text++;
    }
}

static void Line_SpeedValue(uint8_t line[LCD_COLUMNS], uint8_t position, uint8_t value)
{
    if (value >= 10u) {
        line[position] = (uint8_t)('0' + (value / 10u));
        line[position + 1u] = (uint8_t)('0' + (value % 10u));
    } else {
        line[position] = ' ';
        line[position + 1u] = (uint8_t)('0' + value);
    }
}

static void LCD_ShowMenu(void)
{
    uint8_t first[LCD_COLUMNS];
    uint8_t second[LCD_COLUMNS];
    uint8_t index;

    Line_Blank(first);
    Line_Blank(second);

    if (menuPage == MENU_INPUT) {
        Line_Text(first, 0u, "BEMENET ");
        first[8] = (uint8_t)('0' + (settings.inputTenths / 10u));
        first[9] = '.';
        first[10] = (uint8_t)('0' + (settings.inputTenths % 10u));
        first[11] = 'V';
        Line_Text(second, 0u, "UP/DOWN  MODE=OK");
    } else if (menuPage == MENU_CHARACTER_SPEED) {
        Line_Text(first, 0u, "KAR FEL:");
        Line_SpeedValue(first, 8u, settings.characterRise);
        Line_Text(first, 11u, "LE:");
        Line_SpeedValue(first, 14u, settings.characterFall);
        Line_Text(second, 0u, "UP=FEL DOWN=LE");
    } else if (menuPage == MENU_DISPLAY_TYPE) {
        Line_Text(first, 0u, "UZEM: ");
        if (settings.displayMode == VU_DISPLAY_CARACTER) {
            Line_Text(first, 6u, "KARAKTER");
        } else {
            Line_Text(first, 6u, "5 LEPCSO");
        }
        Line_Text(second, 0u, "UP/DOWN MODE=OK");
    } else {
        Line_Text(first, 0u, "LEP FEL:");
        Line_SpeedValue(first, 8u, settings.stepRise);
        Line_Text(first, 11u, "LE:");
        Line_SpeedValue(first, 14u, settings.stepFall);
        Line_Text(second, 0u, "UP=FEL DOWN=LE");
    }

    LCD_Clear();
    LCD_SetCursor(0u, 0u);
    for (index = 0u; index < LCD_COLUMNS; index++) {
        LCD_WriteChar(first[index]);
    }
    LCD_SetCursor(0u, 1u);
    for (index = 0u; index < LCD_COLUMNS; index++) {
        LCD_WriteChar(second[index]);
    }
    LCD_Invalidate();
}

static void Settings_Defaults(void)
{
    settings.inputTenths = 10u;
    settings.characterRise = 3u;
    settings.characterFall = 3u;
    settings.displayMode = VU_DISPLAY_CARACTER;
    settings.stepRise = 3u;
    settings.stepFall = 3u;
    settings.characterPattern = 0u;
    settings.stepPattern = 0u;
    settings.direction = VU_DIR_LEFT_TO_RIGHT;
}

static void Settings_Validate(void)
{
    if ((settings.inputTenths < 1u) || (settings.inputTenths > 20u)) {
        settings.inputTenths = 10u;
    }
    if ((settings.characterRise < 1u) ||
        (settings.characterRise > CHARACTER_SPEED_MAX)) {
        settings.characterRise = 3u;
    }
    if ((settings.characterFall < 1u) ||
        (settings.characterFall > CHARACTER_SPEED_MAX)) {
        settings.characterFall = 3u;
    }
    if ((settings.stepRise < 1u) || (settings.stepRise > STEP_SPEED_MAX)) {
        settings.stepRise = 3u;
    }
    if ((settings.stepFall < 1u) || (settings.stepFall > STEP_SPEED_MAX)) {
        settings.stepFall = 3u;
    }
    if (settings.displayMode > VU_DISPLAY_STEP) {
        settings.displayMode = VU_DISPLAY_CARACTER;
    }
    if (settings.direction > VU_DIR_CENTER_OUT) {
        settings.direction = VU_DIR_LEFT_TO_RIGHT;
    }
    if ((settings.displayMode == VU_DISPLAY_STEP) &&
        (settings.direction == VU_DIR_CENTER_OUT)) {
        settings.direction = VU_DIR_LEFT_TO_RIGHT;
    }
    if (settings.characterPattern >= CARACTER_PATTERN_COUNT) {
        settings.characterPattern = 0u;
    }
    if (settings.stepPattern >= LEPCSO_PATTERN_COUNT) {
        settings.stepPattern = 0u;
    }
}

static uint8_t EEPROM_Read(uint8_t address)
{
    EEADR = address;
    EECON1bits.EEPGD = 0;
    EECON1bits.CFGS = 0;
    EECON1bits.RD = 1;
    return EEDATA;
}

static void EEPROM_Write(uint8_t address, uint8_t value)
{
    uint8_t interruptsEnabled;

    EEADR = address;
    EEDATA = value;
    EECON1bits.EEPGD = 0;
    EECON1bits.CFGS = 0;
    EECON1bits.WREN = 1;
    interruptsEnabled = INTCONbits.GIE;
    INTCONbits.GIE = 0;
    EECON2 = 0x55u;
    EECON2 = 0xAAu;
    EECON1bits.WR = 1;
    INTCONbits.GIE = interruptsEnabled;
    while (EECON1bits.WR != 0u) {
    }
    EECON1bits.WREN = 0;
}

static uint8_t Settings_Checksum(void)
{
    return (uint8_t)(EEPROM_MAGIC ^ settings.inputTenths ^ settings.characterRise ^
                     settings.characterFall ^ settings.displayMode ^ settings.stepRise ^
                     settings.stepFall ^ settings.characterPattern ^ settings.stepPattern ^
                     settings.direction ^ 0x5Au);
}

static void Settings_Load(void)
{
    if (EEPROM_Read(EE_MAGIC) != EEPROM_MAGIC) {
        Settings_Defaults();
        return;
    }

    settings.inputTenths = EEPROM_Read(EE_INPUT_TENTHS);
    settings.characterRise = EEPROM_Read(EE_CHAR_RISE);
    settings.characterFall = EEPROM_Read(EE_CHAR_FALL);
    settings.displayMode = EEPROM_Read(EE_DISPLAY_MODE);
    settings.stepRise = EEPROM_Read(EE_STEP_RISE);
    settings.stepFall = EEPROM_Read(EE_STEP_FALL);
    settings.characterPattern = EEPROM_Read(EE_CHAR_PATTERN);
    settings.stepPattern = EEPROM_Read(EE_STEP_PATTERN);
    settings.direction = EEPROM_Read(EE_DIRECTION);

    if (EEPROM_Read(EE_CHECK) != Settings_Checksum()) {
        Settings_Defaults();
    } else {
        Settings_Validate();
    }
}

static void Settings_Save(void)
{
    Settings_Validate();
    EEPROM_Write(EE_MAGIC, EEPROM_MAGIC);
    EEPROM_Write(EE_INPUT_TENTHS, settings.inputTenths);
    EEPROM_Write(EE_CHAR_RISE, settings.characterRise);
    EEPROM_Write(EE_CHAR_FALL, settings.characterFall);
    EEPROM_Write(EE_DISPLAY_MODE, settings.displayMode);
    EEPROM_Write(EE_STEP_RISE, settings.stepRise);
    EEPROM_Write(EE_STEP_FALL, settings.stepFall);
    EEPROM_Write(EE_CHAR_PATTERN, settings.characterPattern);
    EEPROM_Write(EE_STEP_PATTERN, settings.stepPattern);
    EEPROM_Write(EE_DIRECTION, settings.direction);
    EEPROM_Write(EE_CHECK, Settings_Checksum());
}

static void Value_Next(uint8_t *value, uint8_t maximum)
{
    if (*value >= maximum) {
        *value = 1u;
    } else {
        (*value)++;
    }
}

static void Value_Previous(uint8_t *value, uint8_t maximum)
{
    if (*value <= 1u) {
        *value = maximum;
    } else {
        (*value)--;
    }
}

static void HandleMeterButtons(uint8_t events)
{
    if ((events & BUTTON_MENU) != 0u) {
        appState = APP_MENU;
        menuPage = MENU_INPUT;
        LCD_ShowMenu();
        return;
    }

    if (settings.displayMode == VU_DISPLAY_CARACTER) {
        if ((events & BUTTON_UP) != 0u) {
            settings.characterPattern++;
            if (settings.characterPattern >= CARACTER_PATTERN_COUNT) {
                settings.characterPattern = 0u;
            }
            loadedCharacterPattern = 0xFFu;
            LCD_Invalidate();
            RenderMeter();
        }
        if ((events & BUTTON_DOWN) != 0u) {
            if (settings.characterPattern == 0u) {
                settings.characterPattern = (uint8_t)(CARACTER_PATTERN_COUNT - 1u);
            } else {
                settings.characterPattern--;
            }
            loadedCharacterPattern = 0xFFu;
            LCD_Invalidate();
            RenderMeter();
        }
    } else {
        if ((events & BUTTON_UP) != 0u) {
            settings.stepPattern++;
            if (settings.stepPattern >= LEPCSO_PATTERN_COUNT) {
                settings.stepPattern = 0u;
            }
            loadedStepPattern = 0xFFu;
            RenderMeter();
        }
        if ((events & BUTTON_DOWN) != 0u) {
            if (settings.stepPattern == 0u) {
                settings.stepPattern = (uint8_t)(LEPCSO_PATTERN_COUNT - 1u);
            } else {
                settings.stepPattern--;
            }
            loadedStepPattern = 0xFFu;
            RenderMeter();
        }
    }

    if ((events & BUTTON_MODE) != 0u) {
        settings.direction++;
        if ((settings.displayMode == VU_DISPLAY_CARACTER) &&
            (settings.direction > VU_DIR_CENTER_OUT)) {
            settings.direction = VU_DIR_LEFT_TO_RIGHT;
        }
        if ((settings.displayMode == VU_DISPLAY_STEP) &&
            (settings.direction > VU_DIR_RIGHT_TO_LEFT)) {
            settings.direction = VU_DIR_LEFT_TO_RIGHT;
        }
        loadedCharacterPattern = 0xFFu;
        loadedStepPattern = 0xFFu;
        LCD_Invalidate();
        RenderMeter();
    }
}

static void HandleMenuButtons(uint8_t events)
{
    if ((events & BUTTON_MODE) != 0u) {
        Settings_Save();
        appState = APP_METER;
        loadedCharacterPattern = 0xFFu;
        loadedStepPattern = 0xFFu;
        LCD_Invalidate();
        RenderMeter();
        return;
    }

    if ((events & BUTTON_MENU) != 0u) {
        if (menuPage == MENU_STEP_SPEED) {
            menuPage = MENU_INPUT;
        } else {
            menuPage = (MenuPage)(menuPage + 1);
        }
        LCD_ShowMenu();
        return;
    }

    if (menuPage == MENU_INPUT) {
        if ((events & BUTTON_UP) != 0u) {
            Value_Next(&settings.inputTenths, 20u);
        }
        if ((events & BUTTON_DOWN) != 0u) {
            Value_Previous(&settings.inputTenths, 20u);
        }
    } else if (menuPage == MENU_CHARACTER_SPEED) {
        if ((events & BUTTON_UP) != 0u) {
            Value_Next(&settings.characterRise, CHARACTER_SPEED_MAX);
        }
        if ((events & BUTTON_DOWN) != 0u) {
            Value_Next(&settings.characterFall, CHARACTER_SPEED_MAX);
        }
    } else if (menuPage == MENU_DISPLAY_TYPE) {
        if (((events & BUTTON_UP) != 0u) || ((events & BUTTON_DOWN) != 0u)) {
            settings.displayMode = (settings.displayMode == VU_DISPLAY_CARACTER) ?
                                   VU_DISPLAY_STEP : VU_DISPLAY_CARACTER;
            if ((settings.displayMode == VU_DISPLAY_STEP) &&
                (settings.direction == VU_DIR_CENTER_OUT)) {
                settings.direction = VU_DIR_LEFT_TO_RIGHT;
            }
            displayedLeft = 0u;
            displayedRight = 0u;
            loadedCharacterPattern = 0xFFu;
            loadedStepPattern = 0xFFu;
        }
    } else {
        if ((events & BUTTON_UP) != 0u) {
            Value_Next(&settings.stepRise, STEP_SPEED_MAX);
        }
        if ((events & BUTTON_DOWN) != 0u) {
            Value_Next(&settings.stepFall, STEP_SPEED_MAX);
        }
    }
    LCD_ShowMenu();
}
