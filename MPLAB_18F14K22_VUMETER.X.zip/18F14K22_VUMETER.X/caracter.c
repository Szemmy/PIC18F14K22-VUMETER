#include "caracter.h"
#include "lcd_i2c.h"

/* Each selectable character pattern has a separate normal and mirror block. */
static const uint8_t characterNormal[CARACTER_PATTERN_MAX][8] = {
    {0x1F,0x01,0x01,0x01,0x01,0x01,0x01,0x1F},
    {0x10,0x08,0x04,0x03,0x03,0x04,0x08,0x10},
    {0x1C,0x04,0x07,0x07,0x07,0x07,0x04,0x1C},
    {0x00,0x00,0x03,0x1F,0x1F,0x03,0x00,0x00},
    {0x1F,0x01,0x07,0x01,0x01,0x07,0x01,0x1F},
    {0x10,0x18,0x1C,0x1F,0x1F,0x1C,0x18,0x10},
    {0x1F,0x01,0x01,0x19,0x19,0x01,0x01,0x1F},
    {0x07,0x01,0x01,0x1F,0x1F,0x01,0x01,0x07}
};

static const uint8_t characterMirror[CARACTER_PATTERN_MAX][8] = {
    {0x1F,0x10,0x10,0x10,0x10,0x10,0x10,0x1F},
    {0x01,0x02,0x04,0x18,0x18,0x04,0x02,0x01},
    {0x07,0x04,0x1C,0x1C,0x1C,0x1C,0x04,0x07},
    {0x00,0x00,0x18,0x1F,0x1F,0x18,0x00,0x00},
    {0x1F,0x10,0x1C,0x10,0x10,0x1C,0x10,0x1F},
    {0x01,0x03,0x07,0x1F,0x1F,0x07,0x03,0x01},
    {0x1F,0x10,0x10,0x13,0x13,0x10,0x10,0x1F},
    {0x1C,0x10,0x10,0x1F,0x1F,0x10,0x10,0x1C}
};

#define CARACTER_NORMAL_BLOCK  0u
#define CARACTER_MIRROR_BLOCK  1u

void Caracter_LoadPattern(uint8_t pattern)
{
    if (pattern >= CARACTER_PATTERN_COUNT) {
        pattern = 0u;
    }

    LCD_CreateChar(CARACTER_NORMAL_BLOCK, characterNormal[pattern]);
    LCD_CreateChar(CARACTER_MIRROR_BLOCK, characterMirror[pattern]);
}

void Caracter_Render(uint8_t output[], uint8_t columns, uint8_t level,
                     uint8_t pattern, VuDirection direction)
{
    uint8_t index;
    uint8_t left;
    uint8_t right;

    if (pattern >= CARACTER_PATTERN_COUNT) {
        pattern = 0u;
    }
    if (level > columns) {
        level = columns;
    }

    for (index = 0u; index < columns; index++) {
        output[index] = ' ';
    }

    if (direction == VU_DIR_LEFT_TO_RIGHT) {
        for (index = 0u; index < level; index++) {
            output[index] = CARACTER_NORMAL_BLOCK;
        }
    } else if (direction == VU_DIR_RIGHT_TO_LEFT) {
        for (index = 0u; index < level; index++) {
            output[(uint8_t)(columns - 1u - index)] = CARACTER_MIRROR_BLOCK;
        }
    } else {
        if (level == 0u) {
            return;
        }

        /* Centre-out: left side is mirror, right side is normal. */
        left = (uint8_t)(columns / 2u);
        output[left] = CARACTER_NORMAL_BLOCK;
        level--;
        left = (left == 0u) ? columns : (uint8_t)(left - 1u);
        right = (uint8_t)((columns / 2u) + 1u);

        while (level != 0u) {
            if (left < columns) {
                output[left] = CARACTER_MIRROR_BLOCK;
                level--;
                left = (left == 0u) ? columns : (uint8_t)(left - 1u);
            }
            if ((level != 0u) && (right < columns)) {
                output[right] = CARACTER_NORMAL_BLOCK;
                level--;
                right++;
            }
        }
    }
}
