#ifndef LEPCSO_H
#define LEPCSO_H

#include "main.h"
#include "vu_types.h"

/* Set this one value (1..3) to enable more of the built-in step patterns. */
#define LEPCSO_PATTERN_COUNT  19u
#define LEPCSO_PATTERN_MAX    19u

void Lepcso_LoadPattern(uint8_t pattern, bool mirrored);
void Lepcso_Render(uint8_t output[], uint8_t columns, uint8_t level,
                   VuDirection direction);

#endif
