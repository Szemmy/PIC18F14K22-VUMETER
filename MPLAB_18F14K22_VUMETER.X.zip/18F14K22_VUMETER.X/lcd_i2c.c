#include "lcd_i2c.h"

/* This is intentionally the same software-I2C implementation as 18F_VUM. */
#define I2C_SDA_LAT      LATBbits.LATB4
#define I2C_SDA_PORT     PORTBbits.RB4
#define I2C_SDA_TRIS     TRISBbits.TRISB4
#define I2C_SCL_LAT      LATBbits.LATB6
#define I2C_SCL_TRIS     TRISBbits.TRISB6

#define LCD_I2C_ADDRESS  0x27u
#define LCD_RS           0x01u
#define LCD_EN           0x04u
#define LCD_BACKLIGHT    0x08u

static void I2C_Init(void);
static void I2C_Start(void);
static void I2C_Stop(void);
static uint8_t I2C_Write(uint8_t data);
static void LCD_ExpanderWrite(uint8_t data);
static void LCD_PulseEnable(uint8_t data);
static void LCD_Write4Bits(uint8_t data);
static void LCD_Send(uint8_t value, uint8_t mode);
static void LCD_Command(uint8_t command);

void LCD_Init(void)
{
    I2C_Init();
    __delay_ms(50);

    LCD_Write4Bits(0x30u);
    __delay_ms(5);
    LCD_Write4Bits(0x30u);
    __delay_us(150);
    LCD_Write4Bits(0x30u);
    __delay_us(150);
    LCD_Write4Bits(0x20u);
    __delay_us(150);

    LCD_Command(0x28u);                 /* 4-bit, 2 lines */
    LCD_Command(0x0Cu);                 /* display on, cursor off */
    LCD_Command(0x06u);                 /* cursor increments */
    LCD_Clear();
}

void LCD_Clear(void)
{
    LCD_Command(0x01u);
    __delay_ms(2);
}

void LCD_SetCursor(uint8_t column, uint8_t row)
{
    uint8_t address;

    if (column >= LCD_COLUMNS) {
        column = LCD_COLUMNS - 1u;
    }
    address = (row == 0u) ? 0x00u : 0x40u;
    LCD_Command((uint8_t)(0x80u | address | column));
}

void LCD_WriteChar(uint8_t value)
{
    LCD_Send(value, LCD_RS);
}

void LCD_CreateChar(uint8_t location, const uint8_t glyph[8])
{
    uint8_t row;

    LCD_Command((uint8_t)(0x40u | ((location & 0x07u) << 3)));
    for (row = 0u; row < 8u; row++) {
        LCD_WriteChar(glyph[row]);
    }
}

static void I2C_Init(void)
{
    I2C_SDA_LAT = 0;
    I2C_SCL_LAT = 0;
    I2C_SDA_TRIS = 1;
    I2C_SCL_TRIS = 1;
    __delay_ms(10);
}

static void I2C_Start(void)
{
    I2C_SDA_TRIS = 1;
    I2C_SCL_TRIS = 1;
    __delay_us(5);
    I2C_SDA_TRIS = 0;
    __delay_us(5);
    I2C_SCL_TRIS = 0;
    __delay_us(5);
}

static void I2C_Stop(void)
{
    I2C_SDA_TRIS = 0;
    __delay_us(5);
    I2C_SCL_TRIS = 1;
    __delay_us(5);
    I2C_SDA_TRIS = 1;
    __delay_us(5);
}

static uint8_t I2C_Write(uint8_t data)
{
    uint8_t bitCounter;
    uint8_t acknowledge;

    for (bitCounter = 0u; bitCounter < 8u; bitCounter++) {
        if ((data & 0x80u) != 0u) {
            I2C_SDA_TRIS = 1;
        } else {
            I2C_SDA_TRIS = 0;
        }
        __delay_us(2);
        I2C_SCL_TRIS = 1;
        __delay_us(5);
        I2C_SCL_TRIS = 0;
        __delay_us(2);
        data <<= 1;
    }

    I2C_SDA_TRIS = 1;
    __delay_us(2);
    I2C_SCL_TRIS = 1;
    __delay_us(5);
    acknowledge = I2C_SDA_PORT;
    I2C_SCL_TRIS = 0;
    __delay_us(2);
    return acknowledge;
}

static void LCD_ExpanderWrite(uint8_t data)
{
    I2C_Start();
    I2C_Write((uint8_t)(LCD_I2C_ADDRESS << 1));
    I2C_Write((uint8_t)(data | LCD_BACKLIGHT));
    I2C_Stop();
}

static void LCD_PulseEnable(uint8_t data)
{
    LCD_ExpanderWrite((uint8_t)(data | LCD_EN));
    __delay_us(1);
    LCD_ExpanderWrite((uint8_t)(data & (uint8_t)~LCD_EN));
    __delay_us(50);
}

static void LCD_Write4Bits(uint8_t data)
{
    LCD_ExpanderWrite(data);
    LCD_PulseEnable(data);
}

static void LCD_Send(uint8_t value, uint8_t mode)
{
    uint8_t highNibble;
    uint8_t lowNibble;

    highNibble = (uint8_t)(value & 0xF0u);
    lowNibble = (uint8_t)(((uint16_t)value << 4) & 0xF0u);
    LCD_Write4Bits((uint8_t)(highNibble | mode));
    LCD_Write4Bits((uint8_t)(lowNibble | mode));
}

static void LCD_Command(uint8_t command)
{
    LCD_Send(command, 0x00u);
    if ((command == 0x01u) || (command == 0x02u)) {
        __delay_ms(2);
    }
}
