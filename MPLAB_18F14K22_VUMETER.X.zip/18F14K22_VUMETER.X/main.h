#ifndef MAIN_H
#define MAIN_H

/* The hardware uses the external 8 MHz crystal. */
#define _XTAL_FREQ 8000000UL

#include <xc.h>
#include <stdbool.h>
#include <stdint.h>

#endif
