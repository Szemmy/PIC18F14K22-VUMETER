#ifndef CARACTER_H
#define CARACTER_H

#include "main.h"
#include "vu_types.h"

/*
 * Set this one value (1..8) to expose more of the pre-defined patterns.
 * Further patterns may be appended in caracter.c up to CARACTER_PATTERN_MAX.
 */
#define CARACTER_PATTERN_COUNT  8u
#define CARACTER_PATTERN_MAX    8u

void Caracter_LoadPattern(uint8_t pattern);
void Caracter_Render(uint8_t output[], uint8_t columns, uint8_t level,
                     uint8_t pattern, VuDirection direction);

#endif
